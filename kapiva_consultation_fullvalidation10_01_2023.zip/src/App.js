import "./App.css";
import "./assets/style.css";
import Home from "./container/Home";

function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

// App.use(cors());
export default App;
